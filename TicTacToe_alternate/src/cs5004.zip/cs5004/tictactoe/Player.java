package cs5004.tictactoe;

/**
 * Enum for Player X and Player O.
 */
public enum Player {
  X,
  O
}
