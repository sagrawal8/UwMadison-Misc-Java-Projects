package cs5004.tictactoe;

public class main {
  public static void main (String[] args) {
    int x = 5;
    int y = x;
    y = 6;
    System.out.println(x);
    System.out.print(y);
  }
}
