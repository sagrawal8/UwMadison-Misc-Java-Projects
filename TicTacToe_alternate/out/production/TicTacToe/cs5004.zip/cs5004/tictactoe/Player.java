package cs5004.tictactoe;

public enum Player {X, O}
